
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
    private TaskManager taskManager = new TaskManager();

    @Override
    public void start(Stage stage) {
        VBox vbox = new VBox();
        TextField titleField = new TextField();
        TextArea descriptionField = new TextArea();
        Button addButton = new Button("Add Task");
        ListView<String> taskListView = new ListView<>();

        // Load tasks to display
        for (Task task : taskManager.getTasks()) {
            taskListView.getItems().add(task.getTitle());
        }

        addButton.setOnAction(e -> {
            String title = titleField.getText();
            String description = descriptionField.getText();
            taskManager.addTask(title, description);
            taskListView.getItems().add(title);
            titleField.clear();
            descriptionField.clear();
        });

        taskListView.setOnMouseClicked(e -> {
            String selectedTask = taskListView.getSelectionModel().getSelectedItem();
            if (selectedTask != null) {
                for (Task task : taskManager.getTasks()) {
                    if (task.getTitle().equals(selectedTask)) {
                        titleField.setText(task.getTitle());
                        descriptionField.setText(task.getDescription());
                        break;
                    }
                }
            }
        });

        // Update Task Button
        Button updateButton = new Button("Update Task");
        updateButton.setOnAction(e -> {
            String selectedTask = taskListView.getSelectionModel().getSelectedItem();
            String newTitle = titleField.getText();
            String newDescription = descriptionField.getText();
            for (int i = 0; i < taskManager.getTasks().size(); i++) {
                if (taskManager.getTasks().get(i).getTitle().equals(selectedTask)) {
                    taskManager.updateTask(i, newTitle, newDescription);
                    taskListView.getItems().set(i, newTitle);
                    break;
                }
            }
        });

        // Delete Task Button
        Button deleteButton = new Button("Delete Task");
        deleteButton.setOnAction(e -> {
            String selectedTask = taskListView.getSelectionModel().getSelectedItem();
            for (int i = 0; i < taskManager.getTasks().size(); i++) {
                if (taskManager.getTasks().get(i).getTitle().equals(selectedTask)) {
                    taskManager.deleteTask(i);
                    taskListView.getItems().remove(i);
                    break;
                }
            }
        });

        vbox.getChildren().addAll(titleField, descriptionField, addButton, taskListView, updateButton, deleteButton);
        Scene scene = new Scene(vbox, 300, 400);
        stage.setTitle("Task Manager");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
    