
import java.io.*;
import java.util.*;

public class TaskManager {
    private List<Task> tasks;
    private final String fileName = "tasks.txt";

    public TaskManager() {
        tasks = loadTasksFromFile();
    }

    // Load tasks from file
    public List<Task> loadTasksFromFile() {
        List<Task> loadedTasks = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskData = line.split(";");
                if (taskData.length == 2) {
                    loadedTasks.add(new Task(taskData[0], taskData[1]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading tasks: " + e.getMessage());
        }
        return loadedTasks;
    }

    // Save tasks to file
    public void saveTasksToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Task task : tasks) {
                writer.write(task.getTitle() + ";" + task.getDescription());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving tasks: " + e.getMessage());
        }
    }

    // Add Task
    public void addTask(String title, String description) {
        tasks.add(new Task(title, description));
        saveTasksToFile();
    }

    // Get Tasks
    public List<Task> getTasks() {
        return tasks;
    }

    // Update Task
    public void updateTask(int index, String newTitle, String newDescription) {
        Task task = tasks.get(index);
        task.setTitle(newTitle);
        task.setDescription(newDescription);
        saveTasksToFile();
    }

    // Delete Task
    public void deleteTask(int index) {
        tasks.remove(index);
        saveTasksToFile();
    }
}
    